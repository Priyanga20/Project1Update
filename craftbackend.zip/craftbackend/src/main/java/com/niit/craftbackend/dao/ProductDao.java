package com.niit.craftbackend.dao;

import java.util.List;

import com.niit.craftbackend.model.Product;

public interface ProductDao {
	boolean createProduct(Product product);
	boolean updateProduct(Product product);
	boolean deleteProduct(Product product);  
	List<Product> selectAllProduct();
	Product selectOneProduct(int product_id);

}
