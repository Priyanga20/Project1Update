package com.niit.craftbackend.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.craftbackend.dao.UsercredDao;
import com.niit.craftbackend.model.User;
import com.niit.craftbackend.model.Usercred;

public class UsercredDaoImpl implements UsercredDao {
	@Autowired
	SessionFactory sessionFactory;

	@Override
	public boolean createUsercred(Usercred usercred) {
		// TODO Auto-generated method stub
		try
		{
			sessionFactory.getCurrentSession().save(usercred);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}
	}

	@Override
	public boolean updateUsercred(Usercred usercred) {
		// TODO Auto-generated method stub
		try
		{
			sessionFactory.getCurrentSession().update(usercred);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}
	}

	@Override
	public boolean deleteUsercred(Usercred usercred) {
		// TODO Auto-generated method stub
		try
		{
			sessionFactory.getCurrentSession().delete(usercred);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}

	}

	@Override
	public List<Usercred> selectAllUsercred() {
		// TODO Auto-generated method stub
		try
		{
			return sessionFactory.getCurrentSession().createQuery("from Usercred").list();
			
		 
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
			
			
		}

	}

	@Override
	public Usercred selectOneUsercred(int usercred_id) {
		// TODO Auto-generated method stub
		try
		{
			return (Usercred)sessionFactory.getCurrentSession().createQuery("from Usercred where email_Id="+usercred_id).uniqueResult();

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
			
			
		}

	}

}
