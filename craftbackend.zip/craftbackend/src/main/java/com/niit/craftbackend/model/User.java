package com.niit.craftbackend.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
int u_Id;
	@Column(nullable=false,unique=true)
String u_Name;
	@Column(nullable=false,unique=true)
String u_Emailid;
	@Column(nullable=false)
String u_Phoneno;
	@Column(nullable=false,unique=true)
String u_Password;
	public int getU_Id() {
		return u_Id;
	}
	public void setU_Id(int u_Id) {
		this.u_Id = u_Id;
	}
	public String getU_Name() {
		return u_Name;
	}
	public void setU_Name(String u_Name) {
		this.u_Name = u_Name;
	}
	public String getU_Emailid() {
		return u_Emailid;
	}
	public void setU_Emailid(String u_Emailid) {
		this.u_Emailid = u_Emailid;
	}
	public String getU_Phoneno() {
		return u_Phoneno;
	}
	public void setU_Phoneno(String u_Phoneno) {
		this.u_Phoneno = u_Phoneno;
	}
	public String getU_Password() {
		return u_Password;
	}
	public void setU_Password(String u_Password) {
		this.u_Password = u_Password;
	}

}
