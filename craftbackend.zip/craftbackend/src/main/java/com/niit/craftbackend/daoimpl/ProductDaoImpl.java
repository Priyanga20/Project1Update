package com.niit.craftbackend.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.craftbackend.dao.ProductDao;
import com.niit.craftbackend.model.Category;
import com.niit.craftbackend.model.Product;

public class ProductDaoImpl implements ProductDao {
	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public boolean createProduct(Product product) {
		try
		{
			sessionFactory.getCurrentSession().save(product);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}


	}

	@Override
	public boolean updateProduct(Product product) {
		// TODO Auto-generated method stub
		try
		{
			sessionFactory.getCurrentSession().update(product);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}

	}

	@Override
	public boolean deleteProduct(Product product) {
		// TODO Auto-generated method stub
		try
		{
			sessionFactory.getCurrentSession().delete(product);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}

	}

	@Override
	public List<Product> selectAllProduct() {
		try
		{
			return sessionFactory.getCurrentSession().createQuery("from Product").list();
			
		 
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
			
			
		}
	}

	@Override
	public Product selectOneProduct(int product_id) {
		// TODO Auto-generated method stub
		try
		{
			return (Product)sessionFactory.getCurrentSession().createQuery("from Product where p_Id="+product_id).uniqueResult();

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
			
			
		}
	}

}
