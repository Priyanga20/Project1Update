package com.niit.craftbackend.dao;

import java.util.List;

import com.niit.craftbackend.model.Usercred;

public interface UsercredDao {
	boolean createUsercred(Usercred usercred);
	boolean updateUsercred(Usercred usercred);
	boolean deleteUsercred(Usercred usercred);  
	List<Usercred> selectAllUsercred();
	Usercred selectOneUsercred(int usercred_id);

}
