package com.niit.craftbackend.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

public class Product {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int p_Id;
	@Column(nullable=false,unique=true)
	String p_Name;
	@Column(nullable=false,columnDefinition="text")
	String p_Description;
	@ManyToOne
	Category category;
	int p_Quantity;
	float p_Price;
	public int getP_Id() {
		return p_Id;
	}
	public void setP_Id(int p_Id) {
		this.p_Id = p_Id;
	}
	public String getP_Name() {
		return p_Name;
	}
	public void setP_Name(String p_Name) {
		this.p_Name = p_Name;
	}
	public String getP_Description() {
		return p_Description;
	}
	public void setP_Description(String p_Description) {
		this.p_Description = p_Description;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public int getP_Quantity() {
		return p_Quantity;
	}
	public void setP_Quantity(int p_Quantity) {
		this.p_Quantity = p_Quantity;
	}
	public float getP_Price() {
		return p_Price;
	}
	public void setP_Price(float p_Price) {
		this.p_Price = p_Price;
	}
	

}
