package com.niit.craftbackend.model;

import javax.persistence.Column;
import javax.persistence.Transient;

public class Usercred {
	@Column(nullable=false,unique=true)
	String email_Id;
	@Transient
	@Column(nullable=false,unique=true)
	String user_Password;
	@Column(nullable=false)
	String Status;
	@Column(nullable=false)
	String Role;
	public String getEmail_Id() {
		return email_Id;
	}
	public void setEmail_Id(String email_Id) {
		this.email_Id = email_Id;
	}
	public String getUser_Password() {
		return user_Password;
	}
	public void setUser_Password(String user_Password) {
		this.user_Password = user_Password;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	
	

}
