package com.niit.craftbackend.dao;

import java.util.List;

import com.niit.craftbackend.model.User;

public interface UserDao {
	boolean createUser(User user);
	boolean updateProduct(User user);
	boolean deleteUser(User user);  
	List<User> selectAllUser();
	User selectOneUser(int user_id);


}
