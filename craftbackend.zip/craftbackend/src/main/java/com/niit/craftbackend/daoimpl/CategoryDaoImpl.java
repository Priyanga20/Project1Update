package com.niit.craftbackend.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.craftbackend.dao.CategoryDao;
import com.niit.craftbackend.model.Category;

public class CategoryDaoImpl implements CategoryDao {
	@Autowired
	SessionFactory sessionFactory;
	

	@Override
	public boolean createCategory(Category category) {
		// TODO Auto-generated method stub
	try
	{
		sessionFactory.getCurrentSession().save(category);
		return true;
		
	}
	catch(Exception e)
	{
		System.out.println(e.getMessage());
		return false;
		
	}
	}

	@Override
	public boolean updateCategory(Category category) {
		// TODO Auto-generated method stub
		try
		{
			sessionFactory.getCurrentSession().update(category);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}

	}

	@Override
	public boolean deleteCategory(Category category) {
		// TODO Auto-generated method stub
		try
		{
			sessionFactory.getCurrentSession().delete(category);
			return true;
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
			
		}

	}

	@Override
	public List<Category> selectAllCategory() {
		// TODO Auto-generated method stub
		try
		{
			return sessionFactory.getCurrentSession().createQuery("from Category").list();
			
		 
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
			
			
		}

	}

	@Override
	public Category selectOneCategory(int category_id) {
		// TODO Auto-generated method stub
		try
		{
			return (Category)sessionFactory.getCurrentSession().createQuery("from Category where c_Id="+category_id).uniqueResult();

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			return null;
			
			
		}

	}

}
