package com.niit.craftbackend.model;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class Category {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int c_Id;
	@Column(nullable=false,unique=true)
	String c_Name;
	@Column(nullable=false,columnDefinition="text")
    String c_Description;
	public int getC_Id() {
		return c_Id;
	}
	public void setC_Id(int c_Id) {
		this.c_Id = c_Id;
	}
	public String getC_Name() {
		return c_Name;
	}
	public void setC_Name(String c_Name) {
		this.c_Name = c_Name;
	}
	public String getC_Description() {
		return c_Description;
	}
	public void setC_Description(String c_Description) {
		this.c_Description = c_Description;
	}
	



}
